package hello_world_project.team.class_manager;

import android.content.Context;
import android.graphics.Color;
import android.graphics.drawable.ColorDrawable;
import android.graphics.drawable.Drawable;
import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ListAdapter;
import android.widget.ListView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

import java.util.ArrayList;

public class Class_Manager extends AppCompatActivity {

    ArrayList<Course> courses = new ArrayList<>();
    static int current_course =0 ;


    public void updateListView(){
        ArrayList<String> courses_name = new ArrayList<>();
        for(Course course:courses){
            courses_name.add(course.getClassName());
        }
        final ListView listView = (ListView)findViewById(R.id.class_ListView);
        ListAdapter adapter = new ArrayAdapter<String>(this,android.R.layout.simple_list_item_1,courses_name);
        listView.setAdapter(adapter);
        final Context context = this;
        listView.setOnItemClickListener(new AdapterView.OnItemClickListener(){
            @Override
            public void onItemClick(AdapterView<?> parent, View view, int position, long id) {
                Course course = courses.get(position);
                current_course = position;
                setContentView(R.layout.show_class_page);
                TextView class_name_textView = (TextView)findViewById(R.id.class_name_textView);
                TextView starting_hour_textView = (TextView)findViewById(R.id.class_time_starting_hour);
                TextView starting_min_textView = (TextView)findViewById(R.id.class_time_starting_min);
                TextView ending_hour_textView = (TextView)findViewById(R.id.class_time_ending_hour);
                TextView ending_min_textView = (TextView)findViewById(R.id.class_time_ending_min);
                TextView credits_textView = (TextView)findViewById(R.id.credits_textView);
                TextView year_textView = (TextView)findViewById(R.id.year_textView);
                TextView sem_textView = (TextView)findViewById(R.id.sem_textView);



                Button M_BTN = (Button)findViewById(R.id.M_BTN);
                Button T_BTN = (Button)findViewById(R.id.T_BTN);
                Button W_BTN = (Button)findViewById(R.id.W_BTN);
                Button TH_BTN = (Button)findViewById(R.id.TH_BTN);
                Button F_BTN = (Button)findViewById(R.id.F_BTN);

                for (String day:course.getDays()){
                    if(day.equals("M")){
                        M_BTN.setTag("true");
                        M_BTN.setBackgroundColor(Color.RED);
                    }
                    if(day.equals("T")){
                        T_BTN.setTag("true");
                        T_BTN.setBackgroundColor(Color.RED);
                    }
                    if(day.equals("W")){
                        W_BTN.setTag("true");
                        W_BTN.setBackgroundColor(Color.RED);
                    }
                    if(day.equals("TH")){
                        TH_BTN.setTag("true");
                        TH_BTN.setBackgroundColor(Color.RED);
                    }
                    if(day.equals("F")){
                        F_BTN.setTag("true");
                        F_BTN.setBackgroundColor(Color.RED);
                    }
                }

                class_name_textView.setText(course.getClassName());
                starting_hour_textView.setText(String.valueOf(course.getClass_time_starting_hour()));
                starting_min_textView.setText(String.valueOf(course.getClass_time_starting_min()));
                ending_hour_textView.setText(String.valueOf(course.getClass_time_ending_hour()));
                ending_min_textView.setText(String.valueOf(course.getClass_time_ending_min()));
                credits_textView.setText(String.valueOf(course.getCredit()));
                year_textView.setText(course.getYear());
                sem_textView.setText(course.getSem());


            }
        });
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_class_manager);
        updateListView();
    }
    public void add_class_button_clicked(View view){
        setContentView(R.layout.add_class_page);


        String[] year_spinner_array = {"2018","2019","2020","2021","2022","2023","2024","2025"};
        String[] semester_spinner_array = {"Sem 1","Sem 2"};
        Spinner year_spinner = (Spinner) findViewById(R.id.year_spinner);
        Spinner sem_spinner = (Spinner) findViewById(R.id.sem_spinner);
        ArrayAdapter<String> year_adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, year_spinner_array);
        ArrayAdapter<String> sem_adapter= new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, semester_spinner_array);
        year_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sem_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year_spinner.setAdapter(year_adapter);
        sem_spinner.setAdapter(sem_adapter);
    }
    public void day_selector(View view){
        Button button = (Button) findViewById(view.getId());


        if (button.getTag().equals("false")) {
            button.setTag("true");
            button.setBackgroundColor(Color.RED);
        } else {

            button.setTag("false");
            button.setBackgroundColor(Color.LTGRAY);
        }
    }
    public void cancel_button_clicked(View view){
        setContentView(R.layout.activity_class_manager);
        updateListView();
    }

    public void add_button_clicked(View view){


        Spinner year_spinner = (Spinner)findViewById(R.id.year_spinner);
        Spinner sem_spinner = (Spinner)findViewById(R.id.sem_spinner);
        EditText class_name_input = (EditText)findViewById(R.id.class_name_input);
        EditText starting_hour_input = (EditText)findViewById(R.id.class_time_starting_hour);
        EditText starting_min_input = (EditText)findViewById(R.id.class_time_starting_min);
        EditText ending_hour_input = (EditText)findViewById(R.id.class_time_ending_hour);
        EditText ending_min_input = (EditText)findViewById(R.id.class_time_ending_min);
        EditText credit_input = (EditText)findViewById(R.id.credits_input);
        ArrayList<String> days = new ArrayList<>();
        Button M_BTN = (Button)findViewById(R.id.M_BTN);
        Button T_BTN = (Button)findViewById(R.id.T_BTN);
        Button W_BTN = (Button)findViewById(R.id.W_BTN);
        Button TH_BTN = (Button)findViewById(R.id.TH_BTN);
        Button F_BTN = (Button)findViewById(R.id.F_BTN);


        if(M_BTN.getTag().equals("true")){
            days.add("M");
        }
        if(T_BTN.getTag().equals("true")){
            days.add("T");
        }
        if(W_BTN.getTag().equals("true")){
            days.add("W");
        }
        if(TH_BTN.getTag().equals("true")){
            days.add("TH");
        }
        if(F_BTN.getTag().equals("true")){
            days.add("F");
        }

        String year = year_spinner.getSelectedItem().toString();
        String sem = sem_spinner.getSelectedItem().toString();
        String class_name=class_name_input.getText().toString();

        int starting_hour;
        int starting_min;
        int ending_hour;
        int ending_min;
        int credit;

        try {
            starting_hour = Integer.parseInt(starting_hour_input.getText().toString());
            starting_min = Integer.parseInt(starting_min_input.getText().toString());
            ending_hour = Integer.parseInt(ending_hour_input.getText().toString());
            ending_min = Integer.parseInt(ending_min_input.getText().toString());
            credit = Integer.parseInt(credit_input.getText().toString());
        }catch (NumberFormatException e){
            starting_hour = 0;
            starting_min =0;
            ending_hour =0;
            ending_min =0;
            credit =0;
        }

        if(credit<10&&class_name.equals("")!=true&&starting_hour<24&&starting_min<60&&ending_hour<24&&ending_min<60&&starting_hour<=ending_hour&&!(starting_hour==ending_hour&&starting_min>ending_min)) {
            courses.add(new Course(
                    year, sem, class_name, days, starting_hour, starting_min, ending_hour, ending_min, credit
            ));

            setContentView(R.layout.activity_class_manager);
            updateListView();
        }
    }

    public void save_button_clicked(View view){

        Spinner year_spinner = (Spinner)findViewById(R.id.year_spinner);
        Spinner sem_spinner = (Spinner)findViewById(R.id.sem_spinner);
        EditText class_name_input = (EditText)findViewById(R.id.class_name_input);
        EditText starting_hour_input = (EditText)findViewById(R.id.class_time_starting_hour);
        EditText starting_min_input = (EditText)findViewById(R.id.class_time_starting_min);
        EditText ending_hour_input = (EditText)findViewById(R.id.class_time_ending_hour);
        EditText ending_min_input = (EditText)findViewById(R.id.class_time_ending_min);
        EditText credit_input = (EditText)findViewById(R.id.credits_input);
        ArrayList<String> days = new ArrayList<>();
        Button M_BTN = (Button)findViewById(R.id.M_BTN);
        Button T_BTN = (Button)findViewById(R.id.T_BTN);
        Button W_BTN = (Button)findViewById(R.id.W_BTN);
        Button TH_BTN = (Button)findViewById(R.id.TH_BTN);
        Button F_BTN = (Button)findViewById(R.id.F_BTN);


        if(M_BTN.getTag().equals("true")){
            days.add("M");
        }
        if(T_BTN.getTag().equals("true")){
            days.add("T");
        }
        if(W_BTN.getTag().equals("true")){
            days.add("W");
        }
        if(TH_BTN.getTag().equals("true")){
            days.add("TH");
        }
        if(F_BTN.getTag().equals("true")){
            days.add("F");
        }

        String year = year_spinner.getSelectedItem().toString();
        String sem = sem_spinner.getSelectedItem().toString();
        String class_name=class_name_input.getText().toString();

        int starting_hour;
        int starting_min;
        int ending_hour;
        int ending_min;
        int credit;

        try {
            starting_hour = Integer.parseInt(starting_hour_input.getText().toString());

        }catch (NumberFormatException e){
            starting_hour = 0;

        }

        try {
            starting_min = Integer.parseInt(starting_min_input.getText().toString());
            ending_hour = Integer.parseInt(ending_hour_input.getText().toString());
            ending_min = Integer.parseInt(ending_min_input.getText().toString());
            credit = Integer.parseInt(credit_input.getText().toString());
        }catch (NumberFormatException e) {
            starting_min = 0;
            ending_hour = 0;
            ending_min = 0;
            credit = 0;
        }

        if(credit<10&&class_name.equals("")!=true&&starting_hour<24&&starting_min<60&&ending_hour<24&&ending_min<60&&starting_hour<=ending_hour&&!(starting_hour==ending_hour&&starting_min>ending_min)) {
            courses.set(current_course,new Course(
                    year, sem, class_name, days, starting_hour, starting_min, ending_hour, ending_min, credit
            ));

            setContentView(R.layout.activity_class_manager);
            updateListView();
        }
    }

    public void delete_button_clicked(View view){
        courses.remove(current_course);
        setContentView(R.layout.activity_class_manager);
        updateListView();
    }

    public void edit_button_clicked(View view){
        Course course = courses.get(current_course);

        setContentView(R.layout.edit_class_page);
        EditText class_name_input = (EditText)findViewById(R.id.class_name_input);
        EditText starting_hour_input = (EditText)findViewById(R.id.class_time_starting_hour);
        EditText starting_min_input = (EditText)findViewById(R.id.class_time_starting_min);
        EditText ending_hour_input = (EditText)findViewById(R.id.class_time_ending_hour);
        EditText ending_min_input = (EditText)findViewById(R.id.class_time_ending_min);
        EditText credits_input = (EditText)findViewById(R.id.credits_input);

        String[] year_spinner_array = {"2018","2019","2020","2021","2022","2023","2024","2025"};
        String[] semester_spinner_array = {"Sem 1","Sem 2"};
        Spinner year_spinner = (Spinner) findViewById(R.id.year_spinner);
        Spinner sem_spinner = (Spinner) findViewById(R.id.sem_spinner);
        ArrayAdapter<String> year_adapter = new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, year_spinner_array);
        ArrayAdapter<String> sem_adapter= new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, semester_spinner_array);
        year_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        sem_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        year_spinner.setAdapter(year_adapter);
        sem_spinner.setAdapter(sem_adapter);
        int year_index=0;
        int sem_index=0;
        for (String year:year_spinner_array){
            if(year.equals(course.getYear())){
                break;
            }
            year_index++;
        }
        for (String sem:semester_spinner_array){
            if(sem.equals(course.getSem())){
                break;
            }
            sem_index++;
        }
        year_spinner.setSelection(year_index);
        sem_spinner.setSelection(sem_index);

        Button M_BTN = (Button)findViewById(R.id.M_BTN);
        Button T_BTN = (Button)findViewById(R.id.T_BTN);
        Button W_BTN = (Button)findViewById(R.id.W_BTN);
        Button TH_BTN = (Button)findViewById(R.id.TH_BTN);
        Button F_BTN = (Button)findViewById(R.id.F_BTN);

        for (String day:course.getDays()){
            if(day.equals("M")){
                M_BTN.setTag("true");
                M_BTN.setBackgroundColor(Color.RED);
            }
            if(day.equals("T")){
                T_BTN.setTag("true");
                T_BTN.setBackgroundColor(Color.RED);
            }
            if(day.equals("W")){
                W_BTN.setTag("true");
                W_BTN.setBackgroundColor(Color.RED);
            }
            if(day.equals("TH")){
                TH_BTN.setTag("true");
                TH_BTN.setBackgroundColor(Color.RED);
            }
            if(day.equals("F")){
                F_BTN.setTag("true");
                F_BTN.setBackgroundColor(Color.RED);
            }
        }

        class_name_input.setText(course.getClassName());
        starting_hour_input.setText(String.valueOf(course.getClass_time_starting_hour()));
        starting_min_input.setText(String.valueOf(course.getClass_time_starting_min()));
        ending_hour_input.setText(String.valueOf(course.getClass_time_ending_hour()));
        ending_min_input.setText(String.valueOf(course.getClass_time_ending_min()));
        credits_input.setText(String.valueOf(course.getCredit()));
    }


    String name, grade;
    int credit;

    double gradeValue=0;

    EditText nameInput;
    EditText creditInput;
    EditText gradeInput;


    Button calculatorGPA;

    ArrayList<String> nameArray = new ArrayList<>();
    ArrayList<Integer>creditArray = new ArrayList<>();
    ArrayList<String>gradeArray = new ArrayList<>();

    int totalCredit = 0;
    double totalPts =0;
    public void gpa_cal_BTN_clicked(View view){
        setContentView(R.layout.gpa_calculator);
        nameInput = (EditText) findViewById(R.id.classInput);
        creditInput = (EditText) findViewById(R.id.creditsInput);
        gradeInput = (EditText) findViewById(R.id.gradeInput);

        Button submitButton = (Button) findViewById(R.id.submitButton);

        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                name = nameInput.getText().toString();
                credit = Integer.valueOf(creditInput.getText().toString());
                grade = gradeInput.getText().toString();

                if (grade.equals("A"))
                    gradeValue = 4.00;
                else if (grade.equals("A-"))
                    gradeValue = 3.67;
                else if (grade.equals("B+"))
                    gradeValue = 3.33;
                else if (grade.equals("B"))
                    gradeValue = 3.00;
                else if (grade.equals("B-"))
                    gradeValue = 2.67;
                else if (grade.equals("C+"))
                    gradeValue = 2.33;
                else if (grade.equals("C"))
                    gradeValue = 2.00;
                else if (grade.equals("D+"))
                    gradeValue = 1.33;
                else if (grade.equals("D"))
                    gradeValue = 1.00;
                else if (grade.equals("F"))
                    gradeValue = 0;

                double pts = gradeValue * Double.valueOf(creditInput.getText().toString());


                nameArray.add(name);
                creditArray.add(credit);
                gradeArray.add(grade);
                totalCredit+=credit;
                totalPts+=pts;
            }

        });
        calculatorGPA = (Button) findViewById(R.id.calculatorGPA);
        calculatorGPA.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                TextView textView = (TextView)findViewById(R.id.textView3);
                textView.setText("Your GPA is: " + totalPts / totalCredit);
                System.out.println();
                System.out.printf("Your GPA is: " + "%.2f", totalPts / totalCredit);

            }

        });
    }

    public void class_list_BTN_clicked(View view){
        setContentView(R.layout.activity_class_manager);
        updateListView();
    }
    public void schedule_BTN_clicked(View view){
        setContentView(R.layout.schedule);
        String[] day_spinner_array = {"Monday","Tuesday","Wednesday","Thursday","Friday"};
        Spinner day_spinner = (Spinner) findViewById(R.id.day_spinner);
        ArrayAdapter<String> day_adapter= new ArrayAdapter<String>(this,
                android.R.layout.simple_spinner_item, day_spinner_array);
        day_adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        day_spinner.setAdapter(day_adapter);
    }

}