package hello_world_project.team.class_manager;

import java.util.ArrayList;

/**
 * Created by iseungheon on 2018. 9. 15..
 */

public class Course {
    String year;
    String sem;
    String className;
    ArrayList<String> days= new ArrayList<>();
    int class_time_starting_hour;
    int class_time_starting_min;
    int class_time_ending_hour;
    int class_time_ending_min;
    int credit;

    public Course(String year, String sem, String className, ArrayList<String> days, int class_time_starting_hour, int class_time_starting_min, int class_time_ending_hour, int class_time_ending_min, int credit) {
        this.year = year;
        this.sem = sem;
        this.className = className;
        this.days = days;
        this.class_time_starting_hour = class_time_starting_hour;
        this.class_time_starting_min = class_time_starting_min;
        this.class_time_ending_hour = class_time_ending_hour;
        this.class_time_ending_min = class_time_ending_min;
        this.credit = credit;
    }

    public String getYear() {
        return year;
    }

    public String getSem() {
        return sem;
    }

    public String getClassName() {
        return className;
    }

    public ArrayList<String> getDays() {
        return days;
    }

    public int getClass_time_starting_hour() {
        return class_time_starting_hour;
    }

    public int getClass_time_starting_min() {
        return class_time_starting_min;
    }

    public int getClass_time_ending_hour() {
        return class_time_ending_hour;
    }

    public int getClass_time_ending_min() {
        return class_time_ending_min;
    }

    public int getCredit() {
        return credit;
    }
}
